-- GloboZeca Turismo - initial multi-tenant schema
-- Apply to a NEW Supabase project using the SQL Editor.
-- Review policies before production launch.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  platform_role text not null default 'user'
    check (platform_role in ('user', 'superadmin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tenants (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  business_type text not null default 'restaurant',
  status text not null default 'draft'
    check (status in ('draft', 'published', 'suspended', 'archived')),
  default_locale text not null default 'pt'
    check (default_locale in ('pt', 'en', 'fr')),
  enabled_locales text[] not null default array['pt','en','fr'],
  demo_enabled boolean not null default true,
  demo_expires_at timestamptz,
  plan_code text not null default 'demo'
    check (plan_code in ('demo', 'starter', 'professional', 'business')),
  public_config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tenant_members (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('owner', 'manager', 'editor')),
  created_at timestamptz not null default now(),
  unique (tenant_id, user_id)
);

create table if not exists public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null unique references public.tenants(id) on delete cascade,
  plan_code text not null default 'demo',
  status text not null default 'trial'
    check (status in ('trial', 'active', 'past_due', 'expired', 'cancelled')),
  starts_at timestamptz not null default now(),
  ends_at timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pages (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  page_key text not null,
  is_published boolean not null default false,
  content jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tenant_id, page_key)
);

create table if not exists public.menu_categories (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  name_i18n jsonb not null default '{}'::jsonb,
  description_i18n jsonb not null default '{}'::jsonb,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.menu_products (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  category_id uuid references public.menu_categories(id) on delete set null,
  name_i18n jsonb not null default '{}'::jsonb,
  description_i18n jsonb not null default '{}'::jsonb,
  price numeric(12,2) not null default 0 check (price >= 0),
  currency text not null default 'AOA',
  image_path text,
  is_available boolean not null default true,
  is_featured boolean not null default false,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.galleries (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  title_i18n jsonb not null default '{}'::jsonb,
  description_i18n jsonb not null default '{}'::jsonb,
  media_path text not null,
  media_type text not null default 'image'
    check (media_type in ('image', 'video')),
  alt_i18n jsonb not null default '{}'::jsonb,
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.reservations (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  customer_name text not null,
  phone text not null,
  email text,
  requested_date date,
  requested_time time,
  party_size integer check (party_size is null or party_size between 1 and 100),
  request_type text not null default 'table'
    check (request_type in ('table', 'event', 'camping', 'other')),
  message text,
  status text not null default 'new'
    check (status in ('new', 'contacted', 'confirmed', 'declined', 'cancelled')),
  source text not null default 'website',
  created_at timestamptz not null default now()
);

create table if not exists public.business_hours (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  opens_at time,
  closes_at time,
  is_closed boolean not null default false,
  unique (tenant_id, weekday)
);

create table if not exists public.social_links (
  id uuid primary key default gen_random_uuid(),
  tenant_id uuid not null references public.tenants(id) on delete cascade,
  platform text not null,
  url text not null,
  is_active boolean not null default true,
  sort_order integer not null default 0
);

create table if not exists public.tenant_settings (
  tenant_id uuid primary key references public.tenants(id) on delete cascade,
  whatsapp_phone text,
  public_phone text,
  public_email text,
  address text,
  google_maps_url text,
  latitude numeric(10,7),
  longitude numeric(10,7),
  brand_primary text,
  brand_secondary text,
  logo_path text,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists idx_tenant_members_user on public.tenant_members(user_id);
create index if not exists idx_menu_products_tenant_category on public.menu_products(tenant_id, category_id);
create index if not exists idx_reservations_tenant_created on public.reservations(tenant_id, created_at desc);
create index if not exists idx_pages_tenant_key on public.pages(tenant_id, page_key);

-- Security-definer helpers avoid recursive RLS checks on membership/profile tables.
create or replace function public.is_platform_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles p
    where p.id = auth.uid() and p.platform_role = 'superadmin'
  );
$$;

create or replace function public.has_tenant_role(_tenant_id uuid, _roles text[])
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_platform_admin() or exists (
    select 1 from public.tenant_members tm
    where tm.tenant_id = _tenant_id
      and tm.user_id = auth.uid()
      and tm.role = any(_roles)
  );
$$;

-- Automatically create a basic profile for each authenticated user.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Updated timestamp helper.
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['profiles','tenants','subscriptions','pages','menu_categories','menu_products','tenant_settings'] loop
    execute format('drop trigger if exists set_updated_at on public.%I', t);
    execute format('create trigger set_updated_at before update on public.%I for each row execute procedure public.set_updated_at()', t);
  end loop;
end $$;

-- Enable RLS everywhere.
alter table public.profiles enable row level security;
alter table public.tenants enable row level security;
alter table public.tenant_members enable row level security;
alter table public.subscriptions enable row level security;
alter table public.pages enable row level security;
alter table public.menu_categories enable row level security;
alter table public.menu_products enable row level security;
alter table public.galleries enable row level security;
alter table public.reservations enable row level security;
alter table public.business_hours enable row level security;
alter table public.social_links enable row level security;
alter table public.tenant_settings enable row level security;

-- Profiles: users can read their own profile; only platform admins can change roles.
drop policy if exists "profile_read_self_or_admin" on public.profiles;
create policy "profile_read_self_or_admin" on public.profiles
for select using (id = auth.uid() or public.is_platform_admin());

drop policy if exists "profile_update_self_safe" on public.profiles;
create policy "profile_update_self_safe" on public.profiles
for update using (id = auth.uid() or public.is_platform_admin())
with check (
  public.is_platform_admin()
  or (id = auth.uid() and platform_role = 'user')
);

-- Tenants: authenticated members/admins can read; only platform admins create/delete.
drop policy if exists "tenant_read_members_admin" on public.tenants;
create policy "tenant_read_members_admin" on public.tenants
for select using (public.has_tenant_role(id, array['owner','manager','editor']));

drop policy if exists "tenant_insert_platform_admin" on public.tenants;
create policy "tenant_insert_platform_admin" on public.tenants
for insert with check (public.is_platform_admin());

drop policy if exists "tenant_update_owner_admin" on public.tenants;
create policy "tenant_update_owner_admin" on public.tenants
for update using (public.has_tenant_role(id, array['owner']) )
with check (public.has_tenant_role(id, array['owner']));

drop policy if exists "tenant_delete_platform_admin" on public.tenants;
create policy "tenant_delete_platform_admin" on public.tenants
for delete using (public.is_platform_admin());

-- Membership management.
drop policy if exists "members_read_same_tenant" on public.tenant_members;
create policy "members_read_same_tenant" on public.tenant_members
for select using (public.has_tenant_role(tenant_id, array['owner','manager','editor']));

drop policy if exists "members_manage_owner_admin" on public.tenant_members;
create policy "members_manage_owner_admin" on public.tenant_members
for all using (public.has_tenant_role(tenant_id, array['owner']))
with check (public.has_tenant_role(tenant_id, array['owner']));

-- Tenant-owned tables: owner/manager/editor can read; owner/manager can write.
do $$
declare t text;
begin
  foreach t in array array['pages','menu_categories','menu_products','galleries','business_hours','social_links','tenant_settings'] loop
    execute format('drop policy if exists "tenant_content_read" on public.%I', t);
    execute format('create policy "tenant_content_read" on public.%I for select using (public.has_tenant_role(tenant_id, array[''owner'',''manager'',''editor'']))', t);
    execute format('drop policy if exists "tenant_content_write" on public.%I', t);
    execute format('create policy "tenant_content_write" on public.%I for all using (public.has_tenant_role(tenant_id, array[''owner'',''manager''])) with check (public.has_tenant_role(tenant_id, array[''owner'',''manager'']))', t);
  end loop;
end $$;

-- Subscriptions: only platform admins can manage; tenant owners can read their own.
drop policy if exists "subscription_read_owner_admin" on public.subscriptions;
create policy "subscription_read_owner_admin" on public.subscriptions
for select using (public.has_tenant_role(tenant_id, array['owner']));

drop policy if exists "subscription_manage_admin" on public.subscriptions;
create policy "subscription_manage_admin" on public.subscriptions
for all using (public.is_platform_admin())
with check (public.is_platform_admin());

-- Reservations: public can submit a request only for a published tenant.
-- No public read/update/delete policy is granted.
drop policy if exists "public_submit_reservation" on public.reservations;
create policy "public_submit_reservation" on public.reservations
for insert with check (
  exists (
    select 1 from public.tenants t
    where t.id = tenant_id
      and t.status = 'published'
      and (not t.demo_enabled or t.demo_expires_at is null or t.demo_expires_at > now())
  )
);

drop policy if exists "reservation_read_staff" on public.reservations;
create policy "reservation_read_staff" on public.reservations
for select using (public.has_tenant_role(tenant_id, array['owner','manager']));

drop policy if exists "reservation_update_staff" on public.reservations;
create policy "reservation_update_staff" on public.reservations
for update using (public.has_tenant_role(tenant_id, array['owner','manager']))
with check (public.has_tenant_role(tenant_id, array['owner','manager']));



-- Prevent tenant owners from changing commercial/platform controls.
create or replace function public.protect_tenant_platform_fields()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_platform_admin() then
    new.status := old.status;
    new.demo_enabled := old.demo_enabled;
    new.demo_expires_at := old.demo_expires_at;
    new.plan_code := old.plan_code;
    new.slug := old.slug;
  end if;
  return new;
end;
$$;

drop trigger if exists protect_tenant_platform_fields on public.tenants;
create trigger protect_tenant_platform_fields
before update on public.tenants
for each row execute procedure public.protect_tenant_platform_fields();

-- Public submissions can never self-confirm a booking or spoof their source.
create or replace function public.normalize_public_reservation()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.status := 'new';
  new.source := 'website';
  new.created_at := now();
  return new;
end;
$$;

drop trigger if exists normalize_public_reservation on public.reservations;
create trigger normalize_public_reservation
before insert on public.reservations
for each row execute procedure public.normalize_public_reservation();

-- Public website data will be exposed through carefully scoped server-side queries/RPC,
-- not by granting anonymous SELECT on every tenant table.
