# GloboZeca Turismo — starter

Starter técnico para a plataforma multiempresa de turismo e hotelaria.

## Stack
- Next.js App Router + TypeScript
- Supabase PostgreSQL, Auth, Storage e RLS
- Tailwind CSS
- next-intl (PT/EN/FR)
- Cloudflare Workers para produção comercial (após validação de compatibilidade)

## Estrutura
- `supabase/migrations/001_initial_schema.sql`: schema inicial multi-tenant e políticas RLS.
- `docs/architecture.md`: decisões de arquitectura e regras de segurança.
- `.env.example`: variáveis necessárias (sem segredos).

## Antes de aplicar
1. Criar um projecto Supabase novo.
2. Abrir SQL Editor.
3. Aplicar `001_initial_schema.sql`.
4. Confirmar que todas as tabelas e políticas foram criadas.
5. Configurar Auth e variáveis de ambiente.
6. Criar o primeiro utilizador administrador e promover o seu perfil a `superadmin` através de uma operação controlada no SQL Editor.

**Nunca** colocar `service_role` no browser, GitHub ou ficheiros `.env` versionados.
O SQL é uma base inicial e deve passar por testes de segurança antes de produção.
